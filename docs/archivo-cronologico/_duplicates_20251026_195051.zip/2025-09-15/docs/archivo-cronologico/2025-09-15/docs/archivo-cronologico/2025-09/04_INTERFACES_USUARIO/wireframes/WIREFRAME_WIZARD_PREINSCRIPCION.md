# Wireframe - Wizard de Preinscripción

## 🎯 Objetivo

Formulario paso a paso que guíe al usuario a través del proceso de preinscripción de manera intuitiva y sin fricciones.

## 📱 Estructura del Wizard

### Header del Wizard

```
┌─────────────────────────────────────────────────────────────┐
│  [← Volver]    🏕️ Preinscripción Curso Medio 2025    [❌]  │
│                                                             │
│  [Paso 1] [Paso 2] [Paso 3] [Paso 4] [Paso 5]             │
│  ●───────○───────○───────○───────○                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📝 Paso 1: Información Personal

```
┌─────────────────────────────────────────────────────────────┐
│                    👤 INFORMACIÓN PERSONAL                  │
│                                                             │
│  RUT *                                                      │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 12.345.678-9                                           │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Nombre Completo *                                          │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Juan Carlos Pérez González                             │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Fecha de Nacimiento *                                      │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [📅] 15/03/2005                                        │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Sexo *                                                     │
│  ○ Masculino  ○ Femenino  ○ Otro                           │
│                                                             │
│  Teléfono *                                                 │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ +56 9 1234 5678                                        │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Email *                                                    │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ juan.perez@email.com                                   │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│              [Continuar →]                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🏕️ Paso 2: Información Scout

```
┌─────────────────────────────────────────────────────────────┐
│                    🏕️ INFORMACIÓN SCOUT                    │
│                                                             │
│  Zona *                                                     │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] Biobío                                             │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Distrito *                                                 │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] Concepción                                         │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Grupo *                                                    │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] Grupo 1 "San José"                                 │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Rol en el Grupo *                                          │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] Scout                                              │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Rama *                                                     │
│  ○ Manada (7-11 años)                                       │
│  ● Tropa (11-15 años)                                       │
│  ○ Comunidad (15-18 años)                                   │
│  ○ Clan (18-21 años)                                        │
│                                                             │
│  Años de experiencia scout                                  │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] 3 años                                             │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│              [← Anterior]  [Continuar →]                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🏠 Paso 3: Información de Contacto

```
┌─────────────────────────────────────────────────────────────┐
│                    🏠 INFORMACIÓN DE CONTACTO              │
│                                                             │
│  Dirección *                                                │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Av. Libertador Bernardo O'Higgins 123                  │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Comuna *                                                   │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] Concepción                                         │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Región *                                                   │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [▼] Región del Biobío                                  │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Código Postal                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 4030000                                                │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Contacto de Emergencia *                                   │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Nombre: María González (Madre)                         │ │
│  │ Teléfono: +56 9 8765 4321                             │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│              [← Anterior]  [Continuar →]                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🍽️ Paso 4: Información Médica y Alimentaria

```
┌─────────────────────────────────────────────────────────────┐
│                    🍽️ INFORMACIÓN MÉDICA                   │
│                                                             │
│  Tipo de Alimentación *                                     │
│  ○ Normal                                                   │
│  ● Vegetariana                                              │
│  ○ Vegana                                                   │
│  ○ Sin gluten                                               │
│  ○ Otra: [especificar]                                      │
│                                                             │
│  Alergias Alimentarias                                      │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Mariscos, frutos secos                                 │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Alergias Medicamentos                                      │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Penicilina                                             │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Limitaciones Físicas                                       │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Ninguna                                                │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Medicamentos que toma regularmente                         │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Ninguno                                                │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  Observaciones Médicas                                      │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ Asma leve, llevar inhalador                            │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│              [← Anterior]  [Continuar →]                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📄 Paso 5: Documentos y Confirmación

```
┌─────────────────────────────────────────────────────────────┐
│                    📄 DOCUMENTOS REQUERIDOS                │
│                                                             │
│  Ficha Médica *                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [📎] ficha_medica_juan_perez.pdf (2.3 MB) [🗑️]        │ │
│  └─────────────────────────────────────────────────────────┘ │
│  [📤 Subir archivo]                                         │
│                                                             │
│  Autorización de Padres/Tutores *                           │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [📎] autorizacion_padres.pdf (1.8 MB) [🗑️]            │ │
│  └─────────────────────────────────────────────────────────┘ │
│  [📤 Subir archivo]                                         │
│                                                             │
│  Certificado de Antecedentes (opcional)                     │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ [📤 Subir archivo]                                     │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ ☑️ He leído y acepto los términos y condiciones        │ │
│  │ ☑️ Autorizo el uso de mi imagen para fines promocionales│ │
│  │ ☑️ Confirmo que toda la información es veraz           │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│              [← Anterior]  [🚀 ENVIAR PREINSCRIPCIÓN]      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## ✅ Página de Confirmación

```
┌─────────────────────────────────────────────────────────────┐
│                    ✅ ¡PREINSCRIPCIÓN ENVIADA!              │
│                                                             │
│  🎉 Tu preinscripción ha sido enviada exitosamente          │
│                                                             │
│  📧 Te hemos enviado un email de confirmación a:           │
│     juan.perez@email.com                                    │
│                                                             │
│  📱 Código de seguimiento: ENR-2025-001                    │
│                                                             │
│  📋 Próximos pasos:                                         │
│  • Revisa tu email para más detalles                       │
│  • Espera la validación (2-3 días hábiles)                 │
│  • Recibirás notificaciones sobre el estado                │
│                                                             │
│  🔗 Puedes consultar el estado en:                         │
│     www.scouts.cl/estado/ENR-2025-001                      │
│                                                             │
│              [🏠 Ir al inicio]  [📱 Ver estado]            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🎨 Elementos de Diseño

### Colores

- **Primario:** Verde Scout (#2E7D32)
- **Secundario:** Azul Scout (#1976D2)
- **Éxito:** Verde claro (#4CAF50)
- **Error:** Rojo (#F44336)
- **Advertencia:** Naranja (#FF9800)
- **Info:** Azul claro (#2196F3)

### Componentes

- **Inputs:** Bordes redondeados, focus en verde
- **Botones:** Gradiente sutil, sombra hover
- **Progress bar:** Verde con animación
- **File upload:** Drag & drop con preview
- **Checkboxes:** Estilo Material Design

### Validaciones

- **En tiempo real:** Validación mientras escribe
- **Mensajes de error:** Rojo, icono de alerta
- **Mensajes de éxito:** Verde, icono de check
- **Campos requeridos:** Asterisco rojo

## 📱 Responsive Design

### Mobile

- Wizard en pantalla completa
- Botones de navegación fijos en bottom
- Inputs de tamaño táctil
- Swipe gestures para navegación

### Tablet

- Wizard en modal centrado
- Navegación lateral
- Grid de 2 columnas para campos relacionados

### Desktop

- Wizard en sidebar + contenido principal
- Navegación con teclado (Tab, Enter)
- Tooltips informativos
- Auto-save cada paso

## 🚀 Funcionalidades

### Navegación

- **Anterior/Siguiente:** Botones en cada paso
- **Progress bar:** Indicador visual del progreso
- **Auto-save:** Guardado automático cada paso
- **Validación:** En tiempo real y al enviar

### Upload de Archivos

- **Drag & drop:** Arrastrar archivos
- **Preview:** Vista previa de documentos
- **Validación:** Tipo y tamaño de archivo
- **Compresión:** Optimización automática

### UX/UI

- **Loading states:** Indicadores de carga
- **Error handling:** Mensajes claros de error
- **Success feedback:** Confirmación visual
- **Accessibility:** Navegación por teclado

---

**Documento preparado por:** AI Assistant
**Fecha:** $(date)
**Versión:** 1.0
**Estado:** ✅ WIREFRAME COMPLETADO
