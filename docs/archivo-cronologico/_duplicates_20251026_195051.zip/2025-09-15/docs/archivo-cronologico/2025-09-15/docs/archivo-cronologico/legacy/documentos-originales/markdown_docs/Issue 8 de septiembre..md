## d1. Requisitos Funcionales (RF)

## 2. Requisitos No Funcionales (RNF)

## 3. Flujos

Aquí se incluirán los diagramas de flujo BPMN/UML de los procesos principales:

Preinscripción

Validación de pagos

Acreditación con QR

Generación de reportes

Etc...

## 4. Tablas

Aquí se definirán las estructuras de datos principales:

Participantes

Cursos

Pagos

Roles/Usuario

Reportes

Etc...

La ultimas dos secciones deberian ser definidas en el equipo de base de datos.

## 5. Migración (Por Definir)

Aquí se documentará la estrategia de migración de información desde procesos/manuales a la plataforma digital:

Importación de datos actuales (Excel, Sheets, formularios).

Normalización y validación de datos.

Plan de respaldo y recuperación.

Aqui deberia añadir cosas el equipo de migracion y carga inicial.
