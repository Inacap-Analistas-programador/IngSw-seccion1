# Wireframe - Panel de Administración

## 🎯 Objetivo

Dashboard completo para administradores y coordinadores que permita gestionar cursos, validar preinscripciones, y monitorear el sistema.

## 📱 Estructura del Panel

### Header del Panel

```
┌─────────────────────────────────────────────────────────────┐
│ [🏕️] Sistema Scout    [🔔] [👤] Admin User    [⚙️] [🚪]    │
│                                                             │
│ [Dashboard] [Cursos] [Preinscripciones] [Pagos] [Reportes] │
└─────────────────────────────────────────────────────────────┘
```

## 📊 Dashboard Principal

```
┌─────────────────────────────────────────────────────────────┐
│                    📊 DASHBOARD - CURSO MEDIO 2025          │
│                                                             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│  │ 👥 144      │ │ ✅ 89       │ │ ⏳ 23       │ │ ❌ 12   │ │
│  │ Cupos       │ │ Validados   │ │ Pendientes  │ │ Rechaz. │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 📈 INSCRIPCIONES POR DÍA                               │ │
│  │                                                         │ │
│  │ 50 ┤                                                    │ │
│  │ 40 ┤     ●                                              │ │
│  │ 30 ┤   ●   ●                                            │ │
│  │ 20 ┤ ●       ●                                          │ │
│  │ 10 ┤           ●                                        │ │
│  │  0 └─────────────────────────────────────────────────  │ │
│  │     Ene  Feb  Mar  Abr  May  Jun                       │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 🚨 ALERTAS Y NOTIFICACIONES                            │ │
│  │                                                         │ │
│  │ • 5 preinscripciones pendientes de validación          │ │
│  │ • 3 pagos pendientes de confirmación                   │ │
│  │ • 1 documento rechazado requiere revisión              │ │
│  │                                                         │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📚 Gestión de Cursos

```
┌─────────────────────────────────────────────────────────────┐
│                    📚 GESTIÓN DE CURSOS                     │
│                                                             │
│  [➕ Nuevo Curso]  [📊 Estadísticas]  [⚙️ Configuración]   │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 🔍 Buscar: [________________] [🔍] [📋] [📤] [🔄]      │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ CURSO MEDIO 2025 - ZONA BIOBÍO                         │ │
│  │                                                         │ │
│  │ 📅 15-17 Marzo 2025  📍 Centro Scout  👥 144/144      │ │
│  │                                                         │ │
│  │ Estado: 🟢 Activo    Preinscripciones: 🟢 Abiertas    │ │
│  │                                                         │ │
│  │ [👁️ Ver] [✏️ Editar] [📊 Estadísticas] [🗑️ Eliminar]  │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ CURSO AVANZADO 2025 - ZONA METROPOLITANA               │ │
│  │                                                         │ │
│  │ 📅 22-24 Abril 2025  📍 Campamento  👥 89/120         │ │
│  │                                                         │ │
│  │ Estado: 🟡 En preparación  Preinscripciones: 🔴 Cerradas│ │
│  │                                                         │ │
│  │ [👁️ Ver] [✏️ Editar] [📊 Estadísticas] [🗑️ Eliminar]  │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📝 Validación de Preinscripciones

```
┌─────────────────────────────────────────────────────────────┐
│                📝 VALIDACIÓN DE PREINSCRIPCIONES            │
│                                                             │
│  [🔄] [📊] [📤] [⚙️]  Filtros: [Estado ▼] [Curso ▼] [Fecha] │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ ENR-2025-001  👤 Juan Pérez  📅 15/01/2025  ⏳ Pendiente│ │
│  │                                                         │ │
│  │ 📧 juan.perez@email.com  📱 +56 9 1234 5678            │ │
│  │ 🏕️ Grupo 1 - Tropa  📄 Documentos: ✅ Médica, ⏳ Autor.│ │
│  │                                                         │ │
│  │ [👁️ Revisar] [✅ Validar] [❌ Rechazar] [💬 Comentario] │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ ENR-2025-002  👤 María González  📅 14/01/2025  ⏳ Pend.│ │
│  │                                                         │ │
│  │ 📧 maria.gonzalez@email.com  📱 +56 9 8765 4321        │ │
│  │ 🏕️ Grupo 2 - Comunidad  📄 Documentos: ✅ Todos        │ │
│  │                                                         │ │
│  │ [👁️ Revisar] [✅ Validar] [❌ Rechazar] [💬 Comentario] │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ ENR-2025-003  👤 Carlos Silva  📅 13/01/2025  ✅ Validado│ │
│  │                                                         │ │
│  │ 📧 carlos.silva@email.com  📱 +56 9 5555 1234          │ │
│  │ 🏕️ Grupo 3 - Tropa  📄 Documentos: ✅ Todos            │ │
│  │                                                         │ │
│  │ [👁️ Ver] [💰 Generar Cuotas] [📧 Reenviar Email]      │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 💰 Gestión de Pagos

```
┌─────────────────────────────────────────────────────────────┐
│                    💰 GESTIÓN DE PAGOS                      │
│                                                             │
│  [📤 Importar] [📊 Reportes] [⚙️ Configuración]            │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 🔍 Buscar: [________________] [🔍] [📋] [📤] [🔄]      │ │
│  │ Filtros: [Estado ▼] [Método ▼] [Fecha ▼] [Monto ▼]    │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ PAG-2025-001  👤 Juan Pérez  💰 $50.000  ⏳ Pendiente  │ │
│  │                                                         │ │
│  │ 📅 20/01/2025  🏦 Transferencia  📄 Comprobante: ✅    │ │
│  │ 📧 juan.perez@email.com  📱 +56 9 1234 5678            │ │
│  │                                                         │ │
│  │ [👁️ Ver Comprobante] [✅ Confirmar] [❌ Rechazar]      │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ PAG-2025-002  👤 María González  💰 $50.000  ✅ Confirmado│ │
│  │                                                         │ │
│  │ 📅 19/01/2025  🏦 Transferencia  📄 Comprobante: ✅    │ │
│  │ 📧 maria.gonzalez@email.com  📱 +56 9 8765 4321        │ │
│  │                                                         │ │
│  │ [👁️ Ver] [📧 Reenviar Recibo] [🎫 Generar Credencial] │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📊 Reportes y Estadísticas

```
┌─────────────────────────────────────────────────────────────┐
│                    📊 REPORTES Y ESTADÍSTICAS               │
│                                                             │
│  [📅] [📤] [🔄]  Período: [Enero 2025 ▼] [Generar Reporte] │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 📈 RESUMEN EJECUTIVO                                   │ │
│  │                                                         │ │
│  │ • Total de preinscripciones: 124                       │ │
│  │ • Tasa de validación: 89.5%                            │ │
│  │ • Ingresos confirmados: $4.450.000                     │ │
│  │ • Tasa de conversión: 78.2%                            │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 📊 GRÁFICOS                                            │ │
│  │                                                         │ │
│  │ [📈 Inscripciones por día] [📊 Estado de validaciones] │ │
│  │ [💰 Ingresos por mes] [🏕️ Distribución por zona]      │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 📋 REPORTES DETALLADOS                                 │ │
│  │                                                         │ │
│  │ [📄 Lista de participantes] [💰 Reporte financiero]    │ │
│  │ [📧 Log de comunicaciones] [📊 Análisis de abandono]   │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## ⚙️ Configuración del Sistema

```
┌─────────────────────────────────────────────────────────────┐
│                    ⚙️ CONFIGURACIÓN DEL SISTEMA             │
│                                                             │
│  [👥 Usuarios] [🔐 Permisos] [📧 Email] [🔔 Notificaciones] │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 👥 GESTIÓN DE USUARIOS                                 │ │
│  │                                                         │ │
│  │ [➕ Nuevo Usuario]  [📊 Roles]  [🔐 Permisos]          │ │
│  │                                                         │ │
│  │ ┌─────────────────────────────────────────────────────┐ │ │
│  │ │ 👤 Admin User (admin@scouts.cl) - Administrador    │ │ │
│  │ │ [✏️ Editar] [🔐 Cambiar contraseña] [🗑️ Eliminar]  │ │ │
│  │ └─────────────────────────────────────────────────────┘ │ │
│  │                                                         │ │
│  │ ┌─────────────────────────────────────────────────────┐ │ │
│  │ │ 👤 Coordinador (coord@scouts.cl) - Coordinador     │ │ │
│  │ │ [✏️ Editar] [🔐 Cambiar contraseña] [🗑️ Eliminar]  │ │ │
│  │ └─────────────────────────────────────────────────────┘ │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │ 📧 CONFIGURACIÓN DE EMAIL                              │ │
│  │                                                         │ │
│  │ SMTP Server: [smtp.gmail.com]                          │ │
│  │ Puerto: [587]  SSL: [✅]  Usuario: [admin@scouts.cl]   │ │
│  │                                                         │ │
│  │ [🧪 Probar conexión] [💾 Guardar configuración]        │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🎨 Elementos de Diseño

### Colores

- **Primario:** Verde Scout (#2E7D32)
- **Secundario:** Azul Scout (#1976D2)
- **Éxito:** Verde claro (#4CAF50)
- **Error:** Rojo (#F44336)
- **Advertencia:** Naranja (#FF9800)
- **Info:** Azul claro (#2196F3)
- **Fondo:** Gris claro (#F5F5F5)

### Componentes

- **Cards:** Sombra sutil, bordes redondeados
- **Botones:** Estilo Material Design
- **Tablas:** Filas alternadas, hover effects
- **Modales:** Overlay con blur
- **Tooltips:** Información contextual

### Iconografía

- **Material Icons:** Consistencia visual
- **Estados:** Colores y iconos para cada estado
- **Acciones:** Iconos intuitivos para cada acción

## 📱 Responsive Design

### Mobile

- Sidebar colapsable
- Tablas con scroll horizontal
- Botones de tamaño táctil
- Navegación por tabs

### Tablet

- Sidebar fijo
- Grid de 2 columnas
- Modales adaptativos

### Desktop

- Sidebar expandido
- Múltiples columnas
- Hover effects
- Keyboard shortcuts

## 🚀 Funcionalidades

### Dashboard

- **Métricas en tiempo real:** Actualización automática
- **Gráficos interactivos:** Chart.js o similar
- **Alertas:** Notificaciones push
- **Filtros:** Búsqueda y filtrado avanzado

### Gestión

- **CRUD completo:** Crear, leer, actualizar, eliminar
- **Validación:** En tiempo real
- **Auditoría:** Log de cambios
- **Backup:** Exportación de datos

### Comunicación

- **Email templates:** Plantillas personalizables
- **Notificaciones:** Push, email, SMS
- **Reportes:** Generación automática
- **Integración:** APIs externas

---

**Documento preparado por:** AI Assistant
**Fecha:** $(date)
**Versión:** 1.0
**Estado:** ✅ WIREFRAME COMPLETADO
